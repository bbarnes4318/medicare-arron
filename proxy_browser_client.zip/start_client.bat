@echo off
echo ==========================================
echo INSTALLING DEPENDENCIES...
echo ==========================================
pip install -r requirements.txt

echo.
echo ==========================================
echo STARTING PROXY BROWSER...
echo ==========================================
python launch_browser.py
pause
